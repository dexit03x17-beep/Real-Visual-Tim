# REAL VISUAL TIM (Fabric 1.21.11)

## Как получить готовый `.jar` без установки программ (через браузер на GitHub)
1. Создай новый репозиторий на GitHub и загрузи в него содержимое этого архива.
2. Перейди во вкладку **Actions** -> **Build REAL VISUAL TIM JAR** -> нажми **Run workflow**.
3. После завершения сборки скачай артефакт **real-visual-tim-jar** — внутри будет готовый `.jar` файл для папки `.minecraft/mods/`.

## Локальная сборка (Windows / JDK 21)
Открой папку проекта в IntelliJ IDEA или выполни `gradle build`. Готовый файл появится в `build/libs/`.

## Управление
- **Right Shift** — открыть/закрыть меню REAL VISUAL TIM (можно переназначить во вкладке BINDS).
- **V** — Toggle Sprint (можно переназначить во вкладке BINDS).
- **N / M / H** — базовые макросы `/home`, `/spawn`, `/hub` в режиме `INSERT` (редактируются во вкладке MACROS).
