package com.realvisualtim.setting;

public class ColorSetting extends Setting<Integer> {
    public static final int[] PRESETS = new int[]{
            0xFFA855F7, // Purple
            0xFF8B5CF6, // Violet
            0xFFD946EF, // Magenta
            0xFF38BDF8, // Cyan
            0xFF22C55E, // Green
            0xFFEF4444, // Red
            0xFFFFFFFF  // White
    };

    public ColorSetting(String name, String description, int defaultArgb) {
        super(name, description, defaultArgb);
    }

    public void cyclePreset() {
        int current = getValue();
        for (int i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i] == current) {
                setValue(PRESETS[(i + 1) % PRESETS.length]);
                return;
            }
        }
        setValue(PRESETS[0]);
    }
}
