package com.realvisualtim.module;

import com.realvisualtim.RealVisualTimClient;
import com.realvisualtim.setting.Setting;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int keyBind;
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category, boolean defaultEnabled, int defaultKeyBind) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = defaultEnabled;
        this.keyBind = defaultKeyBind;
    }

    protected <T extends Setting<?>> T addSetting(T setting) {
        this.settings.add(setting);
        return setting;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        Minecraft mc = Minecraft.getInstance();
        if (this.enabled) {
            onEnable(mc);
        } else {
            onDisable(mc);
        }
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        if (client != null) {
            client.autoSave();
        }
    }

    public void setEnabledSilent(boolean enabled) {
        this.enabled = enabled;
    }

    public void toggle() {
        setEnabled(!this.enabled);
    }

    public int getKeyBind() {
        return keyBind;
    }

    public void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        if (client != null) {
            client.autoSave();
        }
    }

    public void setKeyBindSilent(int keyBind) {
        this.keyBind = keyBind;
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public void resetSettings() {
        for (Setting<?> setting : settings) {
            setting.reset();
        }
    }

    public void onEnable(Minecraft mc) {}

    public void onDisable(Minecraft mc) {}

    public void onTick(Minecraft mc) {}
}
