package com.realvisualtim.module;

public enum Category {
    VISUALS("VISUALS"),
    HUD("HUD"),
    BINDS("BINDS"),
    MACROS("MACROS"),
    PROFILES("PROFILES"),
    SETTINGS("SETTINGS");

    private final String title;

    Category(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
