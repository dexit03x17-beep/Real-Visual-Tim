package com.realvisualtim.module.impl.visuals;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.ModeSetting;
import com.realvisualtim.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;

import java.util.Random;

public class HitParticlesModule extends Module {
    public final ModeSetting particleType;
    public final NumberSetting count;
    public final NumberSetting spread;
    private final Random random = new Random();

    public HitParticlesModule() {
        super("Hit Particles", "Spawns visual particles when hitting entities.", Category.VISUALS, true, -1);
        this.particleType = addSetting(new ModeSetting("Particle", "Particle effect type", "Portal", "Portal", "Crit", "Enchant", "Heart", "Soul"));
        this.count = addSetting(new NumberSetting("Count", "Number of particles per hit", 8.0, 1.0, 20.0, 1.0));
        this.spread = addSetting(new NumberSetting("Spread", "Velocity spread", 0.35, 0.05, 1.0, 0.05));
    }

    public void spawnParticles(Entity target) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || target == null) return;

        ParticleOptions particle = switch (particleType.getValue()) {
            case "Crit" -> ParticleTypes.CRIT;
            case "Enchant" -> ParticleTypes.ENCHANT;
            case "Heart" -> ParticleTypes.HEART;
            case "Soul" -> ParticleTypes.SOUL_FIRE_FLAME;
            default -> ParticleTypes.PORTAL;
        };

        int amount = count.getIntValue();
        double s = spread.getValue();
        double x = target.getX();
        double y = target.getY() + target.getBbHeight() * 0.5;
        double z = target.getZ();

        for (int i = 0; i < amount; i++) {
            double vx = (random.nextDouble() - 0.5) * 2.0 * s;
            double vy = (random.nextDouble() - 0.2) * s;
            double vz = (random.nextDouble() - 0.5) * 2.0 * s;
            mc.level.addParticle(particle, x, y, z, vx, vy, vz);
        }
    }
}
