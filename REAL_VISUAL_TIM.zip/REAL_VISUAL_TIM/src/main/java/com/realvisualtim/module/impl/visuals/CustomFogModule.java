package com.realvisualtim.module.impl.visuals;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.ColorSetting;
import com.realvisualtim.setting.NumberSetting;

public class CustomFogModule extends Module {
    public final NumberSetting density;
    public final ColorSetting color;

    public CustomFogModule() {
        super("Custom Fog", "Adds a customizable atmospheric purple/colored fog tint.", Category.VISUALS, false, -1);
        this.density = addSetting(new NumberSetting("Intensity", "Atmospheric haze intensity", 0.25, 0.05, 0.65, 0.05));
        this.color = addSetting(new ColorSetting("Fog Color", "Atmospheric tint color", 0xFF8B5CF6));
    }
}
