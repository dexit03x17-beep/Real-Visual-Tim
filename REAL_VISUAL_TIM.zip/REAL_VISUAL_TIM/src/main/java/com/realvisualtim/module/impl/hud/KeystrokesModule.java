package com.realvisualtim.module.impl.hud;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.NumberSetting;

public class KeystrokesModule extends Module {
    public final NumberSetting posX;
    public final NumberSetting posY;
    public final BooleanSetting showMouse;
    public final BooleanSetting showSpace;

    public KeystrokesModule() {
        super("Keystrokes", "Shows live WASD, Space, and Mouse button presses.", Category.HUD, true, -1);
        this.posX = addSetting(new NumberSetting("Pos X", "Horizontal position", 10.0, 0.0, 800.0, 2.0));
        this.posY = addSetting(new NumberSetting("Pos Y", "Vertical position", 86.0, 0.0, 500.0, 2.0));
        this.showMouse = addSetting(new BooleanSetting("Mouse Buttons", "Show LMB and RMB", true));
        this.showSpace = addSetting(new BooleanSetting("Spacebar", "Show Space key", true));
    }
}
