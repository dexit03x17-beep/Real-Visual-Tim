package com.realvisualtim.module.impl.binds;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class ToggleSprintModule extends Module {
    public final BooleanSetting showHudStatus;

    public ToggleSprintModule() {
        super("Toggle Sprint", "Automatically holds sprint while moving forward.", Category.BINDS, false, GLFW.GLFW_KEY_V);
        this.showHudStatus = addSetting(new BooleanSetting("HUD Indicator", "Show [Sprint: ON] on HUD", true));
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.options == null) return;
        if (mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    public void onDisable(Minecraft mc) {
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
    }
}
