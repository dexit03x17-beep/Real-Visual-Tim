package com.realvisualtim.module.impl.hud;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.NumberSetting;

public class CoordinatesModule extends Module {
    public final NumberSetting posX;
    public final NumberSetting posY;
    public final BooleanSetting showDirection;
    public final BooleanSetting showBackground;

    public CoordinatesModule() {
        super("Coordinates", "Displays player XYZ coordinates and facing direction.", Category.HUD, true, -1);
        this.posX = addSetting(new NumberSetting("Pos X", "Horizontal position", 10.0, 0.0, 800.0, 2.0));
        this.posY = addSetting(new NumberSetting("Pos Y", "Vertical position", 58.0, 0.0, 500.0, 2.0));
        this.showDirection = addSetting(new BooleanSetting("Direction", "Show compass facing", true));
        this.showBackground = addSetting(new BooleanSetting("Background", "Render dark backdrop", true));
    }
}
