package com.realvisualtim.module.impl.visuals;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class FullbrightModule extends Module {
    public final BooleanSetting smoothRefresh;
    private boolean appliedByMod = false;

    public FullbrightModule() {
        super("Fullbright", "Improves visibility in dark areas using client-side night vision.", Category.VISUALS, false, -1);
        this.smoothRefresh = addSetting(new BooleanSetting("No Flicker", "Keeps duration high to prevent fade flicker", true));
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        MobEffectInstance current = mc.player.getEffect(MobEffects.NIGHT_VISION);
        int threshold = smoothRefresh.getValue() ? 400 : 200;
        if (current == null || current.getDuration() < threshold) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, true, false, false));
            appliedByMod = true;
        }
    }

    @Override
    public void onDisable(Minecraft mc) {
        if (mc.player != null && appliedByMod) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
            appliedByMod = false;
        }
    }
}
