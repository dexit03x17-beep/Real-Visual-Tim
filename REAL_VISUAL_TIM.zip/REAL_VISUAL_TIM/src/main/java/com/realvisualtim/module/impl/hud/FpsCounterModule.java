package com.realvisualtim.module.impl.hud;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.NumberSetting;

public class FpsCounterModule extends Module {
    public final NumberSetting posX;
    public final NumberSetting posY;
    public final BooleanSetting showBackground;

    public FpsCounterModule() {
        super("FPS Counter", "Displays current frames per second.", Category.HUD, true, -1);
        this.posX = addSetting(new NumberSetting("Pos X", "Horizontal position", 10.0, 0.0, 800.0, 2.0));
        this.posY = addSetting(new NumberSetting("Pos Y", "Vertical position", 34.0, 0.0, 500.0, 2.0));
        this.showBackground = addSetting(new BooleanSetting("Background", "Render dark backdrop", true));
    }
}
