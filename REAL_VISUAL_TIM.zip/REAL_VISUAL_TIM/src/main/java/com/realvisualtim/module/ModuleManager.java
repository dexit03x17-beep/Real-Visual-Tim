package com.realvisualtim.module;

import com.mojang.blaze3d.platform.InputConstants;
import com.realvisualtim.module.impl.binds.ToggleSprintModule;
import com.realvisualtim.module.impl.hud.CoordinatesModule;
import com.realvisualtim.module.impl.hud.FpsCounterModule;
import com.realvisualtim.module.impl.hud.KeystrokesModule;
import com.realvisualtim.module.impl.hud.WatermarkModule;
import com.realvisualtim.module.impl.visuals.CustomCrosshairModule;
import com.realvisualtim.module.impl.visuals.CustomFogModule;
import com.realvisualtim.module.impl.visuals.DamageTintModule;
import com.realvisualtim.module.impl.visuals.FullbrightModule;
import com.realvisualtim.module.impl.visuals.HitParticlesModule;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, Boolean> keyStates = new HashMap<>();

    public ModuleManager() {
        // VISUALS
        register(new CustomCrosshairModule());
        register(new HitParticlesModule());
        register(new FullbrightModule());
        register(new CustomFogModule());
        register(new DamageTintModule());

        // HUD
        register(new WatermarkModule());
        register(new FpsCounterModule());
        register(new CoordinatesModule());
        register(new KeystrokesModule());

        // BINDS
        register(new ToggleSprintModule());
    }

    private void register(Module module) {
        modules.add(module);
        keyStates.put(module, false);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                result.add(m);
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module m : modules) {
            if (clazz.isInstance(m)) {
                return (T) m;
            }
        }
        return null;
    }

    public Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public void handleKeybinds(long windowHandle) {
        for (Module module : modules) {
            int bind = module.getKeyBind();
            if (bind <= 0) {
                keyStates.put(module, false);
                continue;
            }
            boolean isDown = InputConstants.isKeyDown(windowHandle, bind);
            boolean wasDown = keyStates.getOrDefault(module, false);
            if (isDown && !wasDown) {
                module.toggle();
            }
            keyStates.put(module, isDown);
        }
    }

    public void onTick(Minecraft mc) {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick(mc);
            }
        }
    }
}
