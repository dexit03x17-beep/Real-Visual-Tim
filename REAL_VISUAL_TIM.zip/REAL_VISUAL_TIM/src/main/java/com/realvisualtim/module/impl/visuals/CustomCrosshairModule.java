package com.realvisualtim.module.impl.visuals;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.ColorSetting;
import com.realvisualtim.setting.ModeSetting;
import com.realvisualtim.setting.NumberSetting;

public class CustomCrosshairModule extends Module {
    public final ModeSetting style;
    public final NumberSetting size;
    public final NumberSetting thickness;
    public final NumberSetting gap;
    public final BooleanSetting outline;
    public final ColorSetting color;

    public CustomCrosshairModule() {
        super("Custom Crosshair", "Customizes the in-game crosshair style and color.", Category.VISUALS, false, -1);
        this.style = addSetting(new ModeSetting("Style", "Crosshair shape", "Cross", "Cross", "Dot", "Plus"));
        this.size = addSetting(new NumberSetting("Size", "Arm length in pixels", 5.0, 2.0, 14.0, 1.0));
        this.thickness = addSetting(new NumberSetting("Thickness", "Line thickness", 2.0, 1.0, 4.0, 1.0));
        this.gap = addSetting(new NumberSetting("Gap", "Center gap in pixels", 3.0, 0.0, 10.0, 1.0));
        this.outline = addSetting(new BooleanSetting("Outline", "Draw dark border around crosshair", true));
        this.color = addSetting(new ColorSetting("Color", "Crosshair color", 0xFFA855F7));
    }
}
