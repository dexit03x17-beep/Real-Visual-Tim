package com.realvisualtim.module.impl.visuals;

import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.ColorSetting;
import com.realvisualtim.setting.NumberSetting;

public class DamageTintModule extends Module {
    public final NumberSetting intensity;
    public final NumberSetting borderSize;
    public final ColorSetting color;

    public DamageTintModule() {
        super("Damage Tint", "Shows a smooth colored screen vignette when taking damage.", Category.VISUALS, true, -1);
        this.intensity = addSetting(new NumberSetting("Intensity", "Opacity of the damage flash", 0.45, 0.1, 0.9, 0.05));
        this.borderSize = addSetting(new NumberSetting("Border Size", "Edge vignette thickness", 36.0, 12.0, 96.0, 4.0));
        this.color = addSetting(new ColorSetting("Tint Color", "Damage overlay color", 0xFFEF4444));
    }
}
