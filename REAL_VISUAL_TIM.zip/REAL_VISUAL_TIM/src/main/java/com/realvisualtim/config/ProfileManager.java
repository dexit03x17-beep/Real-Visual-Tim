package com.realvisualtim.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.realvisualtim.RealVisualTimClient;
import com.realvisualtim.macro.Macro;
import com.realvisualtim.macro.MacroManager;
import com.realvisualtim.macro.MacroMode;
import com.realvisualtim.module.Module;
import com.realvisualtim.module.ModuleManager;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.ColorSetting;
import com.realvisualtim.setting.ModeSetting;
import com.realvisualtim.setting.NumberSetting;
import com.realvisualtim.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class ProfileManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path rootDir;
    private final Path profilesDir;
    private final Path metaFile;

    private final ClientSettings clientSettings;
    private final ModuleManager moduleManager;
    private final MacroManager macroManager;

    private String activeProfile = "default";

    public ProfileManager(ClientSettings clientSettings, ModuleManager moduleManager, MacroManager macroManager) {
        this.clientSettings = clientSettings;
        this.moduleManager = moduleManager;
        this.macroManager = macroManager;
        this.rootDir = FabricLoader.getInstance().getConfigDir().resolve("realvisualtim");
        this.profilesDir = rootDir.resolve("profiles");
        this.metaFile = rootDir.resolve("active_profile.json");
    }

    public void initAndLoad() {
        try {
            Files.createDirectories(profilesDir);
            if (Files.exists(metaFile)) {
                String raw = Files.readString(metaFile, StandardCharsets.UTF_8);
                JsonObject meta = JsonParser.parseString(raw).getAsJsonObject();
                if (meta.has("activeProfile")) {
                    activeProfile = sanitizeName(meta.get("activeProfile").getAsString());
                }
            }
            Path profilePath = getProfilePath(activeProfile);
            if (Files.exists(profilePath)) {
                loadProfile(activeProfile);
            } else {
                saveActiveProfile();
            }
        } catch (Exception e) {
            RealVisualTimClient.LOGGER.error("Failed to initialize profiles", e);
        }
    }

    public String getActiveProfile() {
        return activeProfile;
    }

    public List<String> listProfiles() {
        List<String> list = new ArrayList<>();
        try (Stream<Path> stream = Files.list(profilesDir)) {
            stream.filter(p -> p.toString().endsWith(".json")).forEach(p -> {
                String fileName = p.getFileName().toString();
                list.add(fileName.substring(0, fileName.length() - 5));
            });
        } catch (IOException e) {
            RealVisualTimClient.LOGGER.error("Failed to list profiles", e);
        }
        if (list.isEmpty()) {
            list.add(activeProfile);
        }
        Collections.sort(list);
        return list;
    }

    public boolean createProfile(String name) {
        String clean = sanitizeName(name);
        if (clean.isEmpty()) return false;
        activeProfile = clean;
        saveActiveProfile();
        return true;
    }

    public boolean deleteProfile(String name) {
        String clean = sanitizeName(name);
        if (clean.equals("default")) return false;
        try {
            Files.deleteIfExists(getProfilePath(clean));
            if (activeProfile.equals(clean)) {
                activeProfile = "default";
                loadProfile("default");
            }
            return true;
        } catch (IOException e) {
            RealVisualTimClient.LOGGER.error("Failed to delete profile {}", clean, e);
            return false;
        }
    }

    public void saveActiveProfile() {
        try {
            Files.createDirectories(profilesDir);
            JsonObject root = new JsonObject();

            // Client settings
            JsonObject cs = new JsonObject();
            cs.addProperty("accentColor", clientSettings.getAccentColor());
            cs.addProperty("animationsEnabled", clientSettings.isAnimationsEnabled());
            cs.addProperty("animationSpeed", clientSettings.getAnimationSpeed());
            cs.addProperty("autoSave", clientSettings.isAutoSave());
            cs.addProperty("menuKeyCode", clientSettings.getMenuKeyCode());
            root.add("clientSettings", cs);

            // Modules
            JsonObject mods = new JsonObject();
            for (Module module : moduleManager.getModules()) {
                JsonObject mObj = new JsonObject();
                mObj.addProperty("enabled", module.isEnabled());
                mObj.addProperty("keyBind", module.getKeyBind());
                JsonObject sObj = new JsonObject();
                for (Setting<?> setting : module.getSettings()) {
                    if (setting instanceof BooleanSetting b) {
                        sObj.addProperty(b.getName(), b.getValue());
                    } else if (setting instanceof NumberSetting n) {
                        sObj.addProperty(n.getName(), n.getValue());
                    } else if (setting instanceof ModeSetting m) {
                        sObj.addProperty(m.getName(), m.getValue());
                    } else if (setting instanceof ColorSetting c) {
                        sObj.addProperty(c.getName(), c.getValue());
                    }
                }
                mObj.add("settings", sObj);
                mods.add(module.getName(), mObj);
            }
            root.add("modules", mods);

            // Macros
            JsonArray macrosArr = new JsonArray();
            for (Macro macro : macroManager.getMacros()) {
                JsonObject ma = new JsonObject();
                ma.addProperty("id", macro.getId());
                ma.addProperty("name", macro.getName());
                ma.addProperty("command", macro.getCommand());
                ma.addProperty("keyCode", macro.getKeyCode());
                ma.addProperty("mode", macro.getMode().name());
                ma.addProperty("enabled", macro.isEnabled());
                macrosArr.add(ma);
            }
            root.add("macros", macrosArr);

            Files.writeString(getProfilePath(activeProfile), GSON.toJson(root), StandardCharsets.UTF_8);

            JsonObject meta = new JsonObject();
            meta.addProperty("activeProfile", activeProfile);
            Files.writeString(metaFile, GSON.toJson(meta), StandardCharsets.UTF_8);
        } catch (Exception e) {
            RealVisualTimClient.LOGGER.error("Failed to save profile {}", activeProfile, e);
        }
    }

    public void loadProfile(String name) {
        String clean = sanitizeName(name);
        Path path = getProfilePath(clean);
        if (!Files.exists(path)) {
            return;
        }
        try {
            String raw = Files.readString(path, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(raw).getAsJsonObject();

            if (root.has("clientSettings")) {
                JsonObject cs = root.getAsJsonObject("clientSettings");
                if (cs.has("accentColor")) clientSettings.setAccentColor(cs.get("accentColor").getAsInt());
                if (cs.has("animationsEnabled")) clientSettings.setAnimationsEnabled(cs.get("animationsEnabled").getAsBoolean());
                if (cs.has("animationSpeed")) clientSettings.setAnimationSpeed(cs.get("animationSpeed").getAsDouble());
                if (cs.has("autoSave")) clientSettings.setAutoSave(cs.get("autoSave").getAsBoolean());
                if (cs.has("menuKeyCode")) clientSettings.setMenuKeyCode(cs.get("menuKeyCode").getAsInt());
            }

            if (root.has("modules")) {
                JsonObject mods = root.getAsJsonObject("modules");
                for (Module module : moduleManager.getModules()) {
                    if (!mods.has(module.getName())) continue;
                    JsonObject mObj = mods.getAsJsonObject(module.getName());
                    if (mObj.has("enabled")) module.setEnabledSilent(mObj.get("enabled").getAsBoolean());
                    if (mObj.has("keyBind")) module.setKeyBindSilent(mObj.get("keyBind").getAsInt());
                    if (mObj.has("settings")) {
                        JsonObject sObj = mObj.getAsJsonObject("settings");
                        for (Setting<?> setting : module.getSettings()) {
                            if (!sObj.has(setting.getName())) continue;
                            if (setting instanceof BooleanSetting b) {
                                b.setValue(sObj.get(b.getName()).getAsBoolean());
                            } else if (setting instanceof NumberSetting n) {
                                n.setValue(sObj.get(n.getName()).getAsDouble());
                            } else if (setting instanceof ModeSetting m) {
                                m.setValue(sObj.get(m.getName()).getAsString());
                            } else if (setting instanceof ColorSetting c) {
                                c.setValue(sObj.get(c.getName()).getAsInt());
                            }
                        }
                    }
                }
            }

            if (root.has("macros")) {
                List<Macro> loaded = new ArrayList<>();
                for (JsonElement el : root.getAsJsonArray("macros")) {
                    JsonObject ma = el.getAsJsonObject();
                    String mName = ma.has("name") ? ma.get("name").getAsString() : "Macro";
                    String mCmd = ma.has("command") ? ma.get("command").getAsString() : "";
                    int mKey = ma.has("keyCode") ? ma.get("keyCode").getAsInt() : -1;
                    MacroMode mMode = MacroMode.INSERT;
                    if (ma.has("mode")) {
                        try {
                            mMode = MacroMode.valueOf(ma.get("mode").getAsString());
                        } catch (IllegalArgumentException ignored) {}
                    }
                    boolean mEnabled = !ma.has("enabled") || ma.get("enabled").getAsBoolean();
                    Macro macro = new Macro(mName, mCmd, mKey, mMode, mEnabled);
                    if (ma.has("id")) macro.setId(ma.get("id").getAsString());
                    loaded.add(macro);
                }
                macroManager.setMacros(loaded);
            }

            activeProfile = clean;
            JsonObject meta = new JsonObject();
            meta.addProperty("activeProfile", activeProfile);
            Files.writeString(metaFile, GSON.toJson(meta), StandardCharsets.UTF_8);
        } catch (Exception e) {
            RealVisualTimClient.LOGGER.error("Failed to load profile {}", clean, e);
        }
    }

    public void resetAll() {
        clientSettings.resetDefaults();
        for (Module module : moduleManager.getModules()) {
            module.resetSettings();
        }
        macroManager.loadDefaults();
        saveActiveProfile();
    }

    private Path getProfilePath(String name) {
        return profilesDir.resolve(name + ".json");
    }

    private String sanitizeName(String raw) {
        if (raw == null) return "default";
        String clean = raw.trim().replaceAll("[^a-zA-Z0-9_-]", "");
        return clean.isEmpty() ? "default" : clean;
    }
}
