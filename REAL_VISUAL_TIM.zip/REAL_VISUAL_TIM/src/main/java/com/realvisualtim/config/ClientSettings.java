package com.realvisualtim.config;

import org.lwjgl.glfw.GLFW;

public class ClientSettings {
    private int accentColor = 0xFFA855F7; // Purple
    private boolean animationsEnabled = true;
    private double animationSpeed = 1.0;
    private boolean autoSave = true;
    private int menuKeyCode = GLFW.GLFW_KEY_RIGHT_SHIFT;

    public static final int[] ACCENT_PRESETS = new int[]{
            0xFFA855F7, // Purple
            0xFF8B5CF6, // Violet
            0xFFC084FC, // Soft Lavender
            0xFFD946EF, // Fuchsia
            0xFF6366F1  // Indigo
    };

    public int getAccentColor() {
        return accentColor;
    }

    public void setAccentColor(int accentColor) {
        this.accentColor = accentColor;
    }

    public boolean isAnimationsEnabled() {
        return animationsEnabled;
    }

    public void setAnimationsEnabled(boolean animationsEnabled) {
        this.animationsEnabled = animationsEnabled;
    }

    public double getAnimationSpeed() {
        return animationSpeed;
    }

    public void setAnimationSpeed(double animationSpeed) {
        this.animationSpeed = Math.max(0.25, Math.min(2.5, animationSpeed));
    }

    public boolean isAutoSave() {
        return autoSave;
    }

    public void setAutoSave(boolean autoSave) {
        this.autoSave = autoSave;
    }

    public int getMenuKeyCode() {
        return menuKeyCode;
    }

    public void setMenuKeyCode(int menuKeyCode) {
        this.menuKeyCode = menuKeyCode;
    }

    public void resetDefaults() {
        this.accentColor = 0xFFA855F7;
        this.animationsEnabled = true;
        this.animationSpeed = 1.0;
        this.autoSave = true;
        this.menuKeyCode = GLFW.GLFW_KEY_RIGHT_SHIFT;
    }
}
