package com.realvisualtim;

import com.mojang.blaze3d.platform.InputConstants;
import com.realvisualtim.config.ClientSettings;
import com.realvisualtim.config.ProfileManager;
import com.realvisualtim.hud.HudRenderer;
import com.realvisualtim.macro.MacroManager;
import com.realvisualtim.module.ModuleManager;
import com.realvisualtim.module.impl.visuals.HitParticlesModule;
import com.realvisualtim.ui.RealVisualTimScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealVisualTimClient implements ClientModInitializer {
    public static final String MOD_ID = "realvisualtim";
    public static final String MOD_NAME = "REAL VISUAL TIM";
    public static final String VERSION = "1.0.0";

    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static RealVisualTimClient instance;

    private ClientSettings clientSettings;
    private ModuleManager moduleManager;
    private MacroManager macroManager;
    private ProfileManager profileManager;
    private HudRenderer hudRenderer;

    private boolean menuKeyWasDown = false;

    public static RealVisualTimClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        this.clientSettings = new ClientSettings();
        this.moduleManager = new ModuleManager();
        this.macroManager = new MacroManager();
        this.profileManager = new ProfileManager(this.clientSettings, this.moduleManager, this.macroManager);
        this.hudRenderer = new HudRenderer(this.moduleManager, this.clientSettings);

        this.profileManager.initAndLoad();

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        HudRenderCallback.EVENT.register((guiGraphics, tickCounter) ->
                this.hudRenderer.render(guiGraphics, tickCounter.getGameTimeDeltaPartialTick(true)));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClientSide()) {
                HitParticlesModule hitParticles = this.moduleManager.getModule(HitParticlesModule.class);
                if (hitParticles != null && hitParticles.isEnabled()) {
                    hitParticles.spawnParticles(entity);
                }
            }
            return InteractionResult.PASS;
        });

        LOGGER.info("{} v{} initialized.", MOD_NAME, VERSION);
    }

    private void onClientTick(Minecraft mc) {
        if (mc.getWindow() == null) {
            return;
        }

        long windowHandle = mc.getWindow().getWindow();
        int menuKey = clientSettings.getMenuKeyCode();
        boolean menuKeyDown = menuKey > 0 && InputConstants.isKeyDown(windowHandle, menuKey);

        if (menuKeyDown && !menuKeyWasDown) {
            if (mc.screen == null) {
                mc.setScreen(new RealVisualTimScreen());
            } else if (mc.screen instanceof RealVisualTimScreen) {
                mc.setScreen(null);
            }
        }
        menuKeyWasDown = menuKeyDown;

        if (mc.player != null && mc.level != null) {
            if (mc.screen == null) {
                moduleManager.handleKeybinds(windowHandle);
                macroManager.handleMacros(mc, windowHandle);
            }
            moduleManager.onTick(mc);
        }
    }

    public ClientSettings getClientSettings() {
        return clientSettings;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public MacroManager getMacroManager() {
        return macroManager;
    }

    public ProfileManager getProfileManager() {
        return profileManager;
    }

    public void autoSave() {
        if (clientSettings.isAutoSave() && profileManager != null) {
            profileManager.saveActiveProfile();
        }
    }
}
