package com.realvisualtim.ui;

import com.realvisualtim.RealVisualTimClient;
import com.realvisualtim.config.ClientSettings;
import com.realvisualtim.config.ProfileManager;
import com.realvisualtim.macro.Macro;
import com.realvisualtim.macro.MacroManager;
import com.realvisualtim.macro.MacroMode;
import com.realvisualtim.module.Category;
import com.realvisualtim.module.Module;
import com.realvisualtim.setting.BooleanSetting;
import com.realvisualtim.setting.ColorSetting;
import com.realvisualtim.setting.ModeSetting;
import com.realvisualtim.setting.NumberSetting;
import com.realvisualtim.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class RealVisualTimScreen extends Screen {
    private static final int BG_DARK = 0xF0110E1A;
    private static final int SIDEBAR_BG = 0xFF171324;
    private static final int CARD_BG = 0xFF1E1930;
    private static final int CARD_BORDER = 0xFF33294E;
    private static final int TEXT_MAIN = 0xFFF5F3FF;
    private static final int TEXT_MUTED = 0xFFA799C7;

    private Category selectedCategory = Category.VISUALS;
    private double scrollOffset = 0;
    private float openProgress = 0f;

    // Rebinding state
    private Module listeningModule = null;
    private boolean listeningMenuKey = false;
    private boolean listeningMacroKey = false;

    // Slider dragging
    private NumberSetting draggingSlider = null;
    private int draggingSliderX, draggingSliderW;

    // Macro editor state
    private boolean macroFormOpen = false;
    private Macro editingMacro = null;
    private String macroNameInput = "";
    private String macroCmdInput = "/";
    private int macroKeyInput = GLFW.GLFW_KEY_K;
    private MacroMode macroModeInput = MacroMode.INSERT;
    private int activeTextField = 0; // 0=none, 1=macroName, 2=macroCmd, 3=profileName

    // Profile creation input
    private String newProfileInput = "";

    public RealVisualTimScreen() {
        super(Component.literal("REAL VISUAL TIM"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int getWindowX() { return (this.width - 520) / 2; }
    private int getWindowY() { return (this.height - 340) / 2; }
    private int getWindowW() { return 520; }
    private int getWindowH() { return 340; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        ClientSettings settings = client.getClientSettings();
        int accent = settings.getAccentColor();

        if (settings.isAnimationsEnabled()) {
            openProgress = Math.min(1f, openProgress + (float) (0.12 * settings.getAnimationSpeed()));
        } else {
            openProgress = 1f;
        }

        // Dim background
        int dimAlpha = (int) (130 * openProgress);
        g.fill(0, 0, this.width, this.height, (dimAlpha << 24));

        int wx = getWindowX();
        int wy = getWindowY() + (int) ((1f - openProgress) * 18);
        int ww = getWindowW();
        int wh = getWindowH();

        // Main panel
        g.fill(wx, wy, wx + ww, wy + wh, BG_DARK);
        g.renderOutline(wx, wy, ww, wh, accent);

        // Sidebar
        int sideW = 132;
        g.fill(wx, wy, wx + sideW, wy + wh, SIDEBAR_BG);
        g.fill(wx + sideW - 1, wy, wx + sideW, wy + wh, CARD_BORDER);

        // Header logo
        g.fill(wx, wy, wx + sideW, wy + 3, accent);
        g.drawString(font, "REAL VISUAL TIM", wx + 12, wy + 14, TEXT_MAIN, true);
        g.drawString(font, "v" + RealVisualTimClient.VERSION + " • 1.21.11", wx + 12, wy + 26, accent, false);

        // Categories
        int catY = wy + 52;
        for (Category cat : Category.values()) {
            boolean active = cat == selectedCategory;
            boolean hovered = isIn(mouseX, mouseY, wx + 8, catY, sideW - 16, 26);
            int bg = active ? (0x44000000 | (accent & 0x00FFFFFF)) : (hovered ? 0xFF231D38 : 0x00000000);
            if (bg != 0) {
                g.fill(wx + 8, catY, wx + sideW - 8, catY + 26, bg);
            }
            if (active) {
                g.fill(wx + 8, catY + 4, wx + 11, catY + 22, accent);
            }
            g.drawString(font, cat.getTitle(), wx + 18, catY + 9, active ? TEXT_MAIN : TEXT_MUTED, true);
            catY += 30;
        }

        // Active profile badge at sidebar bottom
        g.drawString(font, "Profile: " + client.getProfileManager().getActiveProfile(), wx + 12, wy + wh - 18, TEXT_MUTED, false);

        // Right content area
        int cx = wx + sideW + 12;
        int cy = wy + 12;
        int cw = ww - sideW - 24;
        int ch = wh - 24;

        g.drawString(font, selectedCategory.getTitle(), cx, cy, TEXT_MAIN, true);
        g.fill(cx, cy + 13, cx + cw, cy + 14, CARD_BORDER);

        int contentTop = cy + 20;
        g.enableScissor(cx - 2, contentTop, cx + cw + 2, wy + wh - 8);
        int drawY = contentTop - (int) scrollOffset;

        switch (selectedCategory) {
            case VISUALS, HUD -> renderModuleList(g, client.getModuleManager().getModulesByCategory(selectedCategory), cx, drawY, cw, mouseX, mouseY, accent);
            case BINDS -> renderBindsTab(g, client, cx, drawY, cw, mouseX, mouseY, accent);
            case MACROS -> renderMacrosTab(g, client.getMacroManager(), cx, drawY, cw, mouseX, mouseY, accent);
            case PROFILES -> renderProfilesTab(g, client.getProfileManager(), cx, drawY, cw, mouseX, mouseY, accent);
            case SETTINGS -> renderSettingsTab(g, client, cx, drawY, cw, mouseX, mouseY, accent);
        }

        g.disableScissor();

        if (draggingSlider != null) {
            updateSliderValue(mouseX);
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void renderModuleList(GuiGraphics g, List<Module> modules, int x, int y, int w, int mx, int my, int accent) {
        int curY = y;
        for (Module mod : modules) {
            int cardH = 38 + mod.getSettings().size() * 24;
            g.fill(x, curY, x + w, curY + cardH, CARD_BG);
            g.renderOutline(x, curY, w, cardH, mod.isEnabled() ? accent : CARD_BORDER);

            g.drawString(font, mod.getName(), x + 10, curY + 8, TEXT_MAIN, true);
            g.drawString(font, mod.getDescription(), x + 10, curY + 20, TEXT_MUTED, false);

            // ON/OFF toggle button
            drawToggleSwitch(g, x + w - 48, curY + 10, 38, 16, mod.isEnabled(), accent);

            int sy = curY + 38;
            for (Setting<?> s : mod.getSettings()) {
                g.drawString(font, s.getName(), x + 12, sy + 5, TEXT_MUTED, false);
                if (s instanceof BooleanSetting bs) {
                    drawToggleSwitch(g, x + w - 46, sy + 2, 36, 14, bs.getValue(), accent);
                } else if (s instanceof NumberSetting ns) {
                    int sx = x + w - 140;
                    int sw = 95;
                    double pct = (ns.getValue() - ns.getMin()) / Math.max(0.0001, ns.getMax() - ns.getMin());
                    g.fill(sx, sy + 7, sx + sw, sy + 11, 0xFF2D2645);
                    g.fill(sx, sy + 7, sx + (int) (sw * pct), sy + 11, accent);
                    String valStr = String.format("%.2f", ns.getValue()).replaceAll("\.?0+$", "");
                    g.drawString(font, valStr, sx + sw + 6, sy + 5, TEXT_MAIN, false);
                } else if (s instanceof ModeSetting ms) {
                    drawButton(g, x + w - 96, sy + 1, 86, 16, ms.getValue(), false, accent);
                } else if (s instanceof ColorSetting cs) {
                    g.fill(x + w - 34, sy + 2, x + w - 10, sy + 16, cs.getValue());
                    g.renderOutline(x + w - 34, sy + 2, 24, 14, 0xFFFFFFFF);
                }
                sy += 24;
            }
            curY += cardH + 8;
        }
    }

    private void renderBindsTab(GuiGraphics g, RealVisualTimClient client, int x, int y, int w, int mx, int my, int accent) {
        int curY = y;

        // Menu keybind card
        g.fill(x, curY, x + w, curY + 32, CARD_BG);
        g.renderOutline(x, curY, w, 32, CARD_BORDER);
        g.drawString(font, "Open Menu Key", x + 10, curY + 11, TEXT_MAIN, true);
        String menuKeyLabel = listeningMenuKey ? "Press Key..." : KeyNameUtil.getKeyName(client.getClientSettings().getMenuKeyCode());
        drawButton(g, x + w - 90, curY + 7, 80, 18, menuKeyLabel, listeningMenuKey, accent);
        curY += 40;

        // All modules keybinds
        for (Module mod : client.getModuleManager().getModules()) {
            g.fill(x, curY, x + w, curY + 30, CARD_BG);
            g.renderOutline(x, curY, w, 30, CARD_BORDER);
            g.drawString(font, mod.getName() + " (" + mod.getCategory().getTitle() + ")", x + 10, curY + 10, TEXT_MAIN, false);

            // Toggle for Toggle Sprint directly in BINDS
            if (mod.getCategory() == Category.BINDS) {
                drawToggleSwitch(g, x + w - 140, curY + 7, 38, 16, mod.isEnabled(), accent);
            }

            boolean isListening = listeningModule == mod;
            String bindText = isListening ? "Press Key..." : KeyNameUtil.getKeyName(mod.getKeyBind());
            drawButton(g, x + w - 90, curY + 6, 80, 18, bindText, isListening, accent);
            curY += 36;
        }
    }

    private void renderMacrosTab(GuiGraphics g, MacroManager manager, int x, int y, int w, int mx, int my, int accent) {
        int curY = y;

        drawButton(g, x, curY, 110, 20, macroFormOpen ? "Close Editor" : "+ Add Macro", macroFormOpen, accent);
        g.drawString(font, "INSERT = opens chat | SEND = sends directly", x + 120, curY + 6, TEXT_MUTED, false);
        curY += 28;

        if (macroFormOpen) {
            g.fill(x, curY, x + w, curY + 112, CARD_BG);
            g.renderOutline(x, curY, w, 112, accent);

            // Name input
            g.drawString(font, "Name:", x + 10, curY + 12, TEXT_MUTED, false);
            drawInputBox(g, x + 75, curY + 8, w - 85, 18, macroNameInput, activeTextField == 1, accent);

            // Command input
            g.drawString(font, "Command:", x + 10, curY + 38, TEXT_MUTED, false);
            drawInputBox(g, x + 75, curY + 34, w - 85, 18, macroCmdInput, activeTextField == 2, accent);

            // Key & Mode
            g.drawString(font, "Key:", x + 10, curY + 66, TEXT_MUTED, false);
            String kLabel = listeningMacroKey ? "Press Key..." : KeyNameUtil.getKeyName(macroKeyInput);
            drawButton(g, x + 75, curY + 62, 85, 18, kLabel, listeningMacroKey, accent);

            g.drawString(font, "Mode:", x + 172, curY + 66, TEXT_MUTED, false);
            drawButton(g, x + 210, curY + 62, 75, 18, macroModeInput.name(), false, accent);

            // Save button
            drawButton(g, x + w - 90, curY + 86, 80, 18, "Save Macro", true, accent);
            curY += 120;
        }

        for (Macro m : manager.getMacros()) {
            g.fill(x, curY, x + w, curY + 42, CARD_BG);
            g.renderOutline(x, curY, w, 42, m.isEnabled() ? accent : CARD_BORDER);

            g.drawString(font, m.getName() + "  [" + KeyNameUtil.getKeyName(m.getKeyCode()) + "]", x + 10, curY + 8, TEXT_MAIN, true);
            g.drawString(font, m.getCommand() + "  •  " + m.getMode().name(), x + 10, curY + 23, TEXT_MUTED, false);

            drawToggleSwitch(g, x + w - 138, curY + 13, 36, 16, m.isEnabled(), accent);
            drawButton(g, x + w - 96, curY + 12, 42, 18, "Edit", false, accent);
            drawButton(g, x + w - 48, curY + 12, 40, 18, "Del", false, 0xFFEF4444);
            curY += 48;
        }
    }

    private void renderProfilesTab(GuiGraphics g, ProfileManager pm, int x, int y, int w, int mx, int my, int accent) {
        int curY = y;

        g.fill(x, curY, x + w, curY + 44, CARD_BG);
        g.renderOutline(x, curY, w, 44, CARD_BORDER);
        g.drawString(font, "New Profile:", x + 10, curY + 17, TEXT_MUTED, false);
        drawInputBox(g, x + 85, curY + 13, w - 175, 18, newProfileInput, activeTextField == 3, accent);
        drawButton(g, x + w - 82, curY + 13, 72, 18, "Create", true, accent);
        curY += 52;

        for (String name : pm.listProfiles()) {
            boolean active = name.equals(pm.getActiveProfile());
            g.fill(x, curY, x + w, curY + 34, CARD_BG);
            g.renderOutline(x, curY, w, 34, active ? accent : CARD_BORDER);

            g.drawString(font, name + (active ? " (Active)" : ""), x + 10, curY + 12, active ? TEXT_MAIN : TEXT_MUTED, active);
            drawButton(g, x + w - 144, curY + 8, 44, 18, "Load", active, accent);
            drawButton(g, x + w - 95, curY + 8, 44, 18, "Save", false, accent);
            if (!"default".equals(name)) {
                drawButton(g, x + w - 46, curY + 8, 38, 18, "Del", false, 0xFFEF4444);
            }
            curY += 40;
        }
    }

    private void renderSettingsTab(GuiGraphics g, RealVisualTimClient client, int x, int y, int w, int mx, int my, int accent) {
        ClientSettings cs = client.getClientSettings();
        int curY = y;

        // Accent color presets
        g.fill(x, curY, x + w, curY + 36, CARD_BG);
        g.renderOutline(x, curY, w, 36, CARD_BORDER);
        g.drawString(font, "Theme Accent Color", x + 10, curY + 13, TEXT_MAIN, false);
        int sx = x + w - (ClientSettings.ACCENT_PRESETS.length * 26) - 6;
        for (int col : ClientSettings.ACCENT_PRESETS) {
            g.fill(sx, curY + 9, sx + 20, curY + 27, col);
            if (col == cs.getAccentColor()) {
                g.renderOutline(sx - 1, curY + 8, 22, 20, 0xFFFFFFFF);
            }
            sx += 26;
        }
        curY += 44;

        // Animations toggle
        g.fill(x, curY, x + w, curY + 32, CARD_BG);
        g.renderOutline(x, curY, w, 32, CARD_BORDER);
        g.drawString(font, "Menu Animations", x + 10, curY + 11, TEXT_MAIN, false);
        drawToggleSwitch(g, x + w - 48, curY + 8, 38, 16, cs.isAnimationsEnabled(), accent);
        curY += 38;

        // Auto-save toggle
        g.fill(x, curY, x + w, curY + 32, CARD_BG);
        g.renderOutline(x, curY, w, 32, CARD_BORDER);
        g.drawString(font, "Auto-Save Changes", x + 10, curY + 11, TEXT_MAIN, false);
        drawToggleSwitch(g, x + w - 48, curY + 8, 38, 16, cs.isAutoSave(), accent);
        curY += 38;

        // Reset button
        g.fill(x, curY, x + w, curY + 36, CARD_BG);
        g.renderOutline(x, curY, w, 36, CARD_BORDER);
        g.drawString(font, "Reset All Settings & Macros", x + 10, curY + 13, TEXT_MAIN, false);
        drawButton(g, x + w - 88, curY + 9, 78, 18, "Reset All", false, 0xFFEF4444);
        curY += 44;

        // Info card
        g.fill(x, curY, x + w, curY + 54, CARD_BG);
        g.renderOutline(x, curY, w, 54, accent);
        g.drawString(font, "REAL VISUAL TIM v" + RealVisualTimClient.VERSION, x + 10, curY + 10, TEXT_MAIN, true);
        g.drawString(font, "Minecraft 1.21.11 • Fabric Client-Side Mod", x + 10, curY + 24, TEXT_MUTED, false);
        g.drawString(font, "Configs: .minecraft/config/realvisualtim/", x + 10, curY + 37, TEXT_MUTED, false);
    }

    private void drawToggleSwitch(GuiGraphics g, int x, int y, int w, int h, boolean state, int accent) {
        g.fill(x, y, x + w, y + h, state ? accent : 0xFF332B4A);
        g.renderOutline(x, y, w, h, state ? 0xFFFFFFFF : CARD_BORDER);
        String label = state ? "ON" : "OFF";
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    private void drawButton(GuiGraphics g, int x, int y, int w, int h, String text, boolean highlight, int accent) {
        int bg = highlight ? accent : 0xFF28213D;
        g.fill(x, y, x + w, y + h, bg);
        g.renderOutline(x, y, w, h, highlight ? 0xFFFFFFFF : accent);
        g.drawString(font, text, x + (w - font.width(text)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    private void drawInputBox(GuiGraphics g, int x, int y, int w, int h, String text, boolean focused, int accent) {
        g.fill(x, y, x + w, y + h, 0xFF120F1D);
        g.renderOutline(x, y, w, h, focused ? accent : CARD_BORDER);
        String shown = text + (focused ? "_" : "");
        g.drawString(font, shown, x + 5, y + 5, TEXT_MAIN, false);
    }

    private boolean isIn(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        int wx = getWindowX();
        int wy = getWindowY();
        int ww = getWindowW();
        int sideW = 132;

        // Sidebar clicks
        int catY = wy + 52;
        for (Category cat : Category.values()) {
            if (isIn(mouseX, mouseY, wx + 8, catY, sideW - 16, 26)) {
                selectedCategory = cat;
                scrollOffset = 0;
                activeTextField = 0;
                return true;
            }
            catY += 30;
        }

        int cx = wx + sideW + 12;
        int cy = wy + 32 - (int) scrollOffset;
        int cw = ww - sideW - 24;

        switch (selectedCategory) {
            case VISUALS, HUD -> handleModuleClicks(client.getModuleManager().getModulesByCategory(selectedCategory), cx, cy, cw, mouseX, mouseY);
            case BINDS -> handleBindsClicks(client, cx, cy, cw, mouseX, mouseY);
            case MACROS -> handleMacrosClicks(client.getMacroManager(), cx, cy, cw, mouseX, mouseY);
            case PROFILES -> handleProfilesClicks(client.getProfileManager(), cx, cy, cw, mouseX, mouseY);
            case SETTINGS -> handleSettingsClicks(client, cx, cy, cw, mouseX, mouseY);
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void handleModuleClicks(List<Module> modules, int x, int y, int w, double mx, double my) {
        int curY = y;
        for (Module mod : modules) {
            int cardH = 38 + mod.getSettings().size() * 24;
            if (isIn(mx, my, x + w - 48, curY + 10, 38, 16)) {
                mod.toggle();
                return;
            }
            int sy = curY + 38;
            for (Setting<?> s : mod.getSettings()) {
                if (s instanceof BooleanSetting bs && isIn(mx, my, x + w - 46, sy + 2, 36, 14)) {
                    bs.toggle();
                    RealVisualTimClient.getInstance().autoSave();
                    return;
                } else if (s instanceof NumberSetting ns && isIn(mx, my, x + w - 140, sy + 2, 95, 16)) {
                    draggingSlider = ns;
                    draggingSliderX = x + w - 140;
                    draggingSliderW = 95;
                    updateSliderValue(mx);
                    return;
                } else if (s instanceof ModeSetting ms && isIn(mx, my, x + w - 96, sy + 1, 86, 16)) {
                    ms.cycle();
                    RealVisualTimClient.getInstance().autoSave();
                    return;
                } else if (s instanceof ColorSetting cs && isIn(mx, my, x + w - 34, sy + 2, 24, 14)) {
                    cs.cyclePreset();
                    RealVisualTimClient.getInstance().autoSave();
                    return;
                }
                sy += 24;
            }
            curY += cardH + 8;
        }
    }

    private void handleBindsClicks(RealVisualTimClient client, int x, int y, int w, double mx, double my) {
        int curY = y;
        if (isIn(mx, my, x + w - 90, curY + 7, 80, 18)) {
            listeningMenuKey = !listeningMenuKey;
            listeningModule = null;
            return;
        }
        curY += 40;
        for (Module mod : client.getModuleManager().getModules()) {
            if (mod.getCategory() == Category.BINDS && isIn(mx, my, x + w - 140, curY + 7, 38, 16)) {
                mod.toggle();
                return;
            }
            if (isIn(mx, my, x + w - 90, curY + 6, 80, 18)) {
                listeningModule = (listeningModule == mod) ? null : mod;
                listeningMenuKey = false;
                return;
            }
            curY += 36;
        }
    }

    private void handleMacrosClicks(MacroManager manager, int x, int y, int w, double mx, double my) {
        int curY = y;
        if (isIn(mx, my, x, curY, 110, 20)) {
            macroFormOpen = !macroFormOpen;
            editingMacro = null;
            if (macroFormOpen) {
                macroNameInput = "New Macro";
                macroCmdInput = "/home";
                macroKeyInput = GLFW.GLFW_KEY_K;
                macroModeInput = MacroMode.INSERT;
            }
            return;
        }
        curY += 28;

        if (macroFormOpen) {
            if (isIn(mx, my, x + 75, curY + 8, w - 85, 18)) { activeTextField = 1; return; }
            if (isIn(mx, my, x + 75, curY + 34, w - 85, 18)) { activeTextField = 2; return; }
            if (isIn(mx, my, x + 75, curY + 62, 85, 18)) { listeningMacroKey = true; activeTextField = 0; return; }
            if (isIn(mx, my, x + 210, curY + 62, 75, 18)) { macroModeInput = macroModeInput.next(); return; }
            if (isIn(mx, my, x + w - 90, curY + 86, 80, 18)) {
                if (editingMacro != null) {
                    editingMacro.setName(macroNameInput.isBlank() ? "Macro" : macroNameInput);
                    editingMacro.setCommand(macroCmdInput);
                    editingMacro.setKeyCode(macroKeyInput);
                    editingMacro.setMode(macroModeInput);
                    manager.save();
                } else {
                    manager.addMacro(new Macro(
                            macroNameInput.isBlank() ? "Macro" : macroNameInput,
                            macroCmdInput,
                            macroKeyInput,
                            macroModeInput,
                            true
                    ));
                }
                macroFormOpen = false;
                editingMacro = null;
                activeTextField = 0;
                return;
            }
            curY += 120;
        }

        for (Macro m : List.copyOf(manager.getMacros())) {
            if (isIn(mx, my, x + w - 138, curY + 13, 36, 16)) {
                m.setEnabled(!m.isEnabled());
                manager.save();
                return;
            }
            if (isIn(mx, my, x + w - 96, curY + 12, 42, 18)) {
                editingMacro = m;
                macroNameInput = m.getName();
                macroCmdInput = m.getCommand();
                macroKeyInput = m.getKeyCode();
                macroModeInput = m.getMode();
                macroFormOpen = true;
                return;
            }
            if (isIn(mx, my, x + w - 48, curY + 12, 40, 18)) {
                manager.removeMacro(m);
                return;
            }
            curY += 48;
        }
    }

    private void handleProfilesClicks(ProfileManager pm, int x, int y, int w, double mx, double my) {
        int curY = y;
        if (isIn(mx, my, x + 85, curY + 13, w - 175, 18)) {
            activeTextField = 3;
            return;
        }
        if (isIn(mx, my, x + w - 82, curY + 13, 72, 18)) {
            if (!newProfileInput.isBlank()) {
                pm.createProfile(newProfileInput);
                newProfileInput = "";
                activeTextField = 0;
            }
            return;
        }
        curY += 52;

        for (String name : pm.listProfiles()) {
            if (isIn(mx, my, x + w - 144, curY + 8, 44, 18)) {
                pm.loadProfile(name);
                return;
            }
            if (isIn(mx, my, x + w - 95, curY + 8, 44, 18)) {
                pm.saveActiveProfile();
                return;
            }
            if (!"default".equals(name) && isIn(mx, my, x + w - 46, curY + 8, 38, 18)) {
                pm.deleteProfile(name);
                return;
            }
            curY += 40;
        }
    }

    private void handleSettingsClicks(RealVisualTimClient client, int x, int y, int w, double mx, double my) {
        ClientSettings cs = client.getClientSettings();
        int curY = y;

        int sx = x + w - (ClientSettings.ACCENT_PRESETS.length * 26) - 6;
        for (int col : ClientSettings.ACCENT_PRESETS) {
            if (isIn(mx, my, sx, curY + 9, 20, 18)) {
                cs.setAccentColor(col);
                client.autoSave();
                return;
            }
            sx += 26;
        }
        curY += 44;

        if (isIn(mx, my, x + w - 48, curY + 8, 38, 16)) {
            cs.setAnimationsEnabled(!cs.isAnimationsEnabled());
            client.autoSave();
            return;
        }
        curY += 38;

        if (isIn(mx, my, x + w - 48, curY + 8, 38, 16)) {
            cs.setAutoSave(!cs.isAutoSave());
            client.getProfileManager().saveActiveProfile();
            return;
        }
        curY += 38;

        if (isIn(mx, my, x + w - 88, curY + 9, 78, 18)) {
            client.getProfileManager().resetAll();
        }
    }

    private void updateSliderValue(double mouseX) {
        if (draggingSlider == null) return;
        double pct = Math.max(0.0, Math.min(1.0, (mouseX - draggingSliderX) / (double) draggingSliderW));
        double val = draggingSlider.getMin() + pct * (draggingSlider.getMax() - draggingSlider.getMin());
        draggingSlider.setValue(val);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) {
            draggingSlider = null;
            RealVisualTimClient.getInstance().autoSave();
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = Math.max(0, scrollOffset - verticalAmount * 18);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        RealVisualTimClient client = RealVisualTimClient.getInstance();

        if (listeningMenuKey) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                client.getClientSettings().setMenuKeyCode(keyCode);
                client.autoSave();
            }
            listeningMenuKey = false;
            return true;
        }
        if (listeningModule != null) {
            listeningModule.setKeyBind(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listeningModule = null;
            return true;
        }
        if (listeningMacroKey) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                macroKeyInput = keyCode;
            }
            listeningMacroKey = false;
            return true;
        }

        if (activeTextField != 0) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (activeTextField == 1 && !macroNameInput.isEmpty()) {
                    macroNameInput = macroNameInput.substring(0, macroNameInput.length() - 1);
                } else if (activeTextField == 2 && !macroCmdInput.isEmpty()) {
                    macroCmdInput = macroCmdInput.substring(0, macroCmdInput.length() - 1);
                } else if (activeTextField == 3 && !newProfileInput.isEmpty()) {
                    newProfileInput = newProfileInput.substring(0, newProfileInput.length() - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                activeTextField = 0;
                return true;
            }
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (activeTextField != 0 && chr >= 32) {
            if (activeTextField == 1 && macroNameInput.length() < 24) {
                macroNameInput += chr;
                return true;
            } else if (activeTextField == 2 && macroCmdInput.length() < 64) {
                macroCmdInput += chr;
                return true;
            } else if (activeTextField == 3 && newProfileInput.length() < 20) {
                newProfileInput += chr;
                return true;
            }
        }
        return super.charTyped(chr, modifiers);
    }
}
