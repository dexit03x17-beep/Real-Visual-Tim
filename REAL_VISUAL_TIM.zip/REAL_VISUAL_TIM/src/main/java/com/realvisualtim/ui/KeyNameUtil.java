package com.realvisualtim.ui;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public class KeyNameUtil {
    public static String getKeyName(int keyCode) {
        if (keyCode <= 0) return "NONE";
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (keyCode == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (keyCode == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (keyCode == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (keyCode == GLFW.GLFW_KEY_SPACE) return "SPACE";
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null && !name.isBlank()) {
            return name.toUpperCase();
        }
        return InputConstants.Type.KEYSYM.getOrCreate(keyCode).getDisplayName().getString().toUpperCase();
    }
}
