package com.realvisualtim.macro;

import java.util.UUID;

public class Macro {
    private String id;
    private String name;
    private String command;
    private int keyCode;
    private MacroMode mode;
    private boolean enabled;

    public Macro(String name, String command, int keyCode, MacroMode mode, boolean enabled) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.command = command;
        this.keyCode = keyCode;
        this.mode = mode == null ? MacroMode.INSERT : mode;
        this.enabled = enabled;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public int getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }

    public MacroMode getMode() {
        return mode == null ? MacroMode.INSERT : mode;
    }

    public void setMode(MacroMode mode) {
        this.mode = mode == null ? MacroMode.INSERT : mode;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
