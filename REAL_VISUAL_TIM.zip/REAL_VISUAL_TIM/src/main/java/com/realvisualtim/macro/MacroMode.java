package com.realvisualtim.macro;

public enum MacroMode {
    INSERT,
    SEND;

    public MacroMode next() {
        return this == INSERT ? SEND : INSERT;
    }
}
