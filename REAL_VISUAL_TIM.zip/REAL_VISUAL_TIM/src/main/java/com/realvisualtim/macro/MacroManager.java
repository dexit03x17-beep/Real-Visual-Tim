package com.realvisualtim.macro;

import com.mojang.blaze3d.platform.InputConstants;
import com.realvisualtim.RealVisualTimClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MacroManager {
    private final List<Macro> macros = new ArrayList<>();
    private final Map<String, Boolean> keyStates = new HashMap<>();

    public MacroManager() {
        loadDefaults();
    }

    public void loadDefaults() {
        macros.clear();
        keyStates.clear();
        macros.add(new Macro("Home", "/home", GLFW.GLFW_KEY_N, MacroMode.INSERT, true));
        macros.add(new Macro("Spawn", "/spawn", GLFW.GLFW_KEY_M, MacroMode.INSERT, true));
        macros.add(new Macro("Hub", "/hub", GLFW.GLFW_KEY_H, MacroMode.INSERT, true));
    }

    public List<Macro> getMacros() {
        return macros;
    }

    public void setMacros(List<Macro> newMacros) {
        macros.clear();
        keyStates.clear();
        if (newMacros != null) {
            macros.addAll(newMacros);
        }
    }

    public void addMacro(Macro macro) {
        macros.add(macro);
        save();
    }

    public void removeMacro(Macro macro) {
        macros.remove(macro);
        keyStates.remove(macro.getId());
        save();
    }

    public void save() {
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        if (client != null) {
            client.autoSave();
        }
    }

    public void handleMacros(Minecraft mc, long windowHandle) {
        if (mc.player == null || mc.screen != null) return;

        for (Macro macro : macros) {
            if (!macro.isEnabled() || macro.getKeyCode() <= 0) {
                keyStates.put(macro.getId(), false);
                continue;
            }
            boolean isDown = InputConstants.isKeyDown(windowHandle, macro.getKeyCode());
            boolean wasDown = keyStates.getOrDefault(macro.getId(), false);
            if (isDown && !wasDown) {
                executeMacro(mc, macro);
            }
            keyStates.put(macro.getId(), isDown);
        }
    }

    public void executeMacro(Minecraft mc, Macro macro) {
        String cmd = macro.getCommand();
        if (cmd == null || cmd.isBlank() || mc.player == null || mc.player.connection == null) {
            return;
        }
        String trimmed = cmd.trim();
        if (macro.getMode() == MacroMode.INSERT) {
            mc.setScreen(new ChatScreen(trimmed));
        } else {
            if (trimmed.startsWith("/")) {
                String withoutSlash = trimmed.substring(1).trim();
                if (!withoutSlash.isEmpty()) {
                    mc.player.connection.sendCommand(withoutSlash);
                }
            } else {
                mc.player.connection.sendChat(trimmed);
            }
        }
    }
}
