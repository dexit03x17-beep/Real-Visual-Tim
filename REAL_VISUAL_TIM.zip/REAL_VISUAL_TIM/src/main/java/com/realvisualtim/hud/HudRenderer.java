package com.realvisualtim.hud;

import com.realvisualtim.RealVisualTimClient;
import com.realvisualtim.config.ClientSettings;
import com.realvisualtim.module.ModuleManager;
import com.realvisualtim.module.impl.binds.ToggleSprintModule;
import com.realvisualtim.module.impl.hud.CoordinatesModule;
import com.realvisualtim.module.impl.hud.FpsCounterModule;
import com.realvisualtim.module.impl.hud.KeystrokesModule;
import com.realvisualtim.module.impl.hud.WatermarkModule;
import com.realvisualtim.module.impl.visuals.CustomCrosshairModule;
import com.realvisualtim.module.impl.visuals.CustomFogModule;
import com.realvisualtim.module.impl.visuals.DamageTintModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

public class HudRenderer {
    private final ModuleManager moduleManager;
    private final ClientSettings clientSettings;

    public HudRenderer(ModuleManager moduleManager, ClientSettings clientSettings) {
        this.moduleManager = moduleManager;
        this.clientSettings = clientSettings;
    }

    public void render(GuiGraphics g, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }

        int screenW = mc.getWindow().getGuiScaledWidth();
        int screenH = mc.getWindow().getGuiScaledHeight();
        int accent = clientSettings.getAccentColor();
        Font font = mc.font;

        renderCustomFog(g, screenW, screenH);
        renderDamageTint(g, mc, screenW, screenH);
        renderCustomCrosshair(g, screenW, screenH);
        renderWatermark(g, font, accent);
        renderFps(g, mc, font, accent);
        renderCoordinates(g, mc, font, accent);
        renderKeystrokes(g, mc, font, accent);
        renderToggleSprintStatus(g, font, accent, screenW, screenH);
    }

    private void renderCustomFog(GuiGraphics g, int w, int h) {
        CustomFogModule fog = moduleManager.getModule(CustomFogModule.class);
        if (fog == null || !fog.isEnabled()) return;
        int alpha = (int) (fog.density.getValue() * 110.0);
        int rgb = fog.color.getValue() & 0x00FFFFFF;
        int topColor = (alpha << 24) | rgb;
        int bottomColor = ((alpha / 3) << 24) | rgb;
        g.fillGradient(0, 0, w, h, topColor, bottomColor);
    }

    private void renderDamageTint(GuiGraphics g, Minecraft mc, int w, int h) {
        DamageTintModule mod = moduleManager.getModule(DamageTintModule.class);
        if (mod == null || !mod.isEnabled() || mc.player == null || mc.player.hurtTime <= 0) return;

        float ratio = (float) mc.player.hurtTime / Math.max(1, mc.player.hurtDuration);
        int maxAlpha = (int) (mod.intensity.getValue() * 255.0 * ratio);
        int rgb = mod.color.getValue() & 0x00FFFFFF;
        int edgeColor = (Math.min(255, Math.max(0, maxAlpha)) << 24) | rgb;
        int clearColor = rgb;
        int b = mod.borderSize.getIntValue();

        g.fillGradient(0, 0, w, b, edgeColor, clearColor);
        g.fillGradient(0, h - b, w, h, clearColor, edgeColor);
        g.fill(0, 0, b / 2, h, (Math.min(255, maxAlpha / 2) << 24) | rgb);
        g.fill(w - b / 2, 0, w, h, (Math.min(255, maxAlpha / 2) << 24) | rgb);
    }

    private void renderCustomCrosshair(GuiGraphics g, int w, int h) {
        CustomCrosshairModule mod = moduleManager.getModule(CustomCrosshairModule.class);
        if (mod == null || !mod.isEnabled()) return;

        int cx = w / 2;
        int cy = h / 2;
        int size = mod.size.getIntValue();
        int thick = mod.thickness.getIntValue();
        int gap = mod.gap.getIntValue();
        int col = mod.color.getValue();
        boolean outline = mod.outline.getValue();
        int halfT = thick / 2;

        String style = mod.style.getValue();
        if ("Dot".equals(style)) {
            drawRect(g, cx - halfT - 1, cy - halfT - 1, cx + halfT + 2, cy + halfT + 2, col, outline);
        } else if ("Plus".equals(style)) {
            drawRect(g, cx - size, cy - halfT, cx + size + 1, cy - halfT + thick, col, outline);
            drawRect(g, cx - halfT, cy - size, cx - halfT + thick, cy + size + 1, col, outline);
        } else {
            // Cross with gap
            drawRect(g, cx - gap - size, cy - halfT, cx - gap, cy - halfT + thick, col, outline);
            drawRect(g, cx + gap + 1, cy - halfT, cx + gap + 1 + size, cy - halfT + thick, col, outline);
            drawRect(g, cx - halfT, cy - gap - size, cx - halfT + thick, cy - gap, col, outline);
            drawRect(g, cx - halfT, cy + gap + 1, cx - halfT + thick, cy + gap + 1 + size, col, outline);
        }
    }

    private void drawRect(GuiGraphics g, int x1, int y1, int x2, int y2, int color, boolean outline) {
        if (outline) {
            g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xCC000000);
        }
        g.fill(x1, y1, x2, y2, color);
    }

    private void renderWatermark(GuiGraphics g, Font font, int accent) {
        WatermarkModule mod = moduleManager.getModule(WatermarkModule.class);
        if (mod == null || !mod.isEnabled()) return;

        String text = mod.showVersion.getValue()
                ? RealVisualTimClient.MOD_NAME + " v" + RealVisualTimClient.VERSION
                : RealVisualTimClient.MOD_NAME;
        int x = mod.posX.getIntValue();
        int y = mod.posY.getIntValue();
        int width = font.width(text) + 12;

        if (mod.showBackground.getValue()) {
            g.fill(x, y, x + width, y + 18, 0xCC13111C);
            g.fill(x, y, x + 2, y + 18, accent);
        }
        g.drawString(font, text, x + 6, y + 5, 0xFFF3E8FF, true);
    }

    private void renderFps(GuiGraphics g, Minecraft mc, Font font, int accent) {
        FpsCounterModule mod = moduleManager.getModule(FpsCounterModule.class);
        if (mod == null || !mod.isEnabled()) return;

        String text = "FPS: " + mc.getFps();
        int x = mod.posX.getIntValue();
        int y = mod.posY.getIntValue();
        int width = font.width(text) + 10;

        if (mod.showBackground.getValue()) {
            g.fill(x, y, x + width, y + 16, 0xBB13111C);
            g.fill(x, y, x + 2, y + 16, accent);
        }
        g.drawString(font, text, x + 6, y + 4, 0xFFE9D5FF, true);
    }

    private void renderCoordinates(GuiGraphics g, Minecraft mc, Font font, int accent) {
        CoordinatesModule mod = moduleManager.getModule(CoordinatesModule.class);
        if (mod == null || !mod.isEnabled() || mc.player == null) return;

        int px = (int) Math.floor(mc.player.getX());
        int py = (int) Math.floor(mc.player.getY());
        int pz = (int) Math.floor(mc.player.getZ());
        String dir = mod.showDirection.getValue() ? " [" + mc.player.getDirection().getName().toUpperCase() + "]" : "";
        String text = "XYZ: " + px + ", " + py + ", " + pz + dir;

        int x = mod.posX.getIntValue();
        int y = mod.posY.getIntValue();
        int width = font.width(text) + 10;

        if (mod.showBackground.getValue()) {
            g.fill(x, y, x + width, y + 16, 0xBB13111C);
            g.fill(x, y, x + 2, y + 16, accent);
        }
        g.drawString(font, text, x + 6, y + 4, 0xFFE9D5FF, true);
    }

    private void renderKeystrokes(GuiGraphics g, Minecraft mc, Font font, int accent) {
        KeystrokesModule mod = moduleManager.getModule(KeystrokesModule.class);
        if (mod == null || !mod.isEnabled()) return;

        int x = mod.posX.getIntValue();
        int y = mod.posY.getIntValue();
        int size = 20;
        int gap = 2;

        drawKeyBox(g, font, "W", x + size + gap, y, size, size, mc.options.keyUp.isDown(), accent);
        drawKeyBox(g, font, "A", x, y + size + gap, size, size, mc.options.keyLeft.isDown(), accent);
        drawKeyBox(g, font, "S", x + size + gap, y + size + gap, size, size, mc.options.keyDown.isDown(), accent);
        drawKeyBox(g, font, "D", x + (size + gap) * 2, y + size + gap, size, size, mc.options.keyRight.isDown(), accent);

        int nextY = y + (size + gap) * 2;
        int totalW = size * 3 + gap * 2;

        if (mod.showMouse.getValue()) {
            int halfW = (totalW - gap) / 2;
            drawKeyBox(g, font, "LMB", x, nextY, halfW, 16, mc.options.keyAttack.isDown(), accent);
            drawKeyBox(g, font, "RMB", x + halfW + gap, nextY, totalW - halfW - gap, 16, mc.options.keyUse.isDown(), accent);
            nextY += 16 + gap;
        }
        if (mod.showSpace.getValue()) {
            drawKeyBox(g, font, "SPACE", x, nextY, totalW, 14, mc.options.keyJump.isDown(), accent);
        }
    }

    private void drawKeyBox(GuiGraphics g, Font font, String label, int x, int y, int w, int h, boolean pressed, int accent) {
        int bg = pressed ? (0xCC000000 | (accent & 0x00FFFFFF)) : 0xAA13111C;
        int border = pressed ? 0xFFFFFFFF : (0x88000000 | (accent & 0x00FFFFFF));
        g.fill(x, y, x + w, y + h, bg);
        g.renderOutline(x, y, w, h, border);
        int textW = font.width(label);
        g.drawString(font, label, x + (w - textW) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    private void renderToggleSprintStatus(GuiGraphics g, Font font, int accent, int screenW, int screenH) {
        ToggleSprintModule mod = moduleManager.getModule(ToggleSprintModule.class);
        if (mod == null || !mod.isEnabled() || !mod.showHudStatus.getValue()) return;

        String text = "Toggle Sprint: ON";
        int w = font.width(text) + 10;
        int x = screenW - w - 10;
        int y = screenH - 24;
        g.fill(x, y, x + w, y + 16, 0xBB13111C);
        g.fill(x, y, x + 2, y + 16, accent);
        g.drawString(font, text, x + 6, y + 4, 0xFFE9D5FF, true);
    }
}
