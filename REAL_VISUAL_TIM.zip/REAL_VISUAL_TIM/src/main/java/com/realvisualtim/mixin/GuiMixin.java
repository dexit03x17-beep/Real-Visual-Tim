package com.realvisualtim.mixin;

import com.realvisualtim.RealVisualTimClient;
import com.realvisualtim.module.impl.visuals.CustomCrosshairModule;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class GuiMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void realvisualtim$cancelVanillaCrosshair(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        RealVisualTimClient client = RealVisualTimClient.getInstance();
        if (client == null) return;
        CustomCrosshairModule crosshair = client.getModuleManager().getModule(CustomCrosshairModule.class);
        if (crosshair != null && crosshair.isEnabled()) {
            ci.cancel();
        }
    }
}
